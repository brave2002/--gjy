package MR.json;

import MR.farm.Farm3Demo;
import com.sun.javaws.jnl.RContentDesc;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.codehaus.jackson.map.ObjectMapper;

import javax.jnlp.FileContents;
import java.io.IOException;
import java.util.*;

public class MovieDemo1 {

    //map端
    //消费金额排名前10的同学
    public static class MapTask extends Mapper<LongWritable,Text, Text, DoubleWritable>{
        @Override
        protected void map(LongWritable key,Text value,Context context) throws IOException,InterruptedException{
            //json数据不能切分 mr处理
            ObjectMapper mapper =new ObjectMapper();
            //实体类
            MallBean mallBean = mapper.readValue(value.toString(), MallBean.class);
            //
            context.write(new Text(mallBean.getName()),new DoubleWritable(mallBean.getShopPrice()));
        }
    }
    //reduce端
    public static class ReduceTask extends Reducer<Text,DoubleWritable,Text,DoubleWritable> {
        HashMap<String, Double>hashMap =new HashMap<>();
        @Override           //张三         （5678，2345，123....)
        protected void reduce(Text key,Iterable<DoubleWritable>values,Context context)throws IOException{
            double sum=0;
            for(DoubleWritable value:values){
                sum+=value.get();
            }
            //
            hashMap.put(key.toString(),sum);
        }
        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException{
            Set<Map.Entry<String, Double>> entries =hashMap.entrySet();
            //
            ArrayList<Map.Entry<String,Double>> list = new ArrayList<>(entries);
            //
            list.sort(new Comparator<Map.Entry<String, Double>>() {
                @Override
                public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                    return (int)(o2.getValue()-o1.getValue());
                }
            });
            //
            for(int i=0;i<10;i++){
                context.write(new Text(list.get(i).getKey()), new DoubleWritable(list.get(i).getValue()));
            }

        }
    }

    //main方法  测试提交任务
    public static void main(String[] args) throws Exception {
        System.setProperty("HADOOP_USER_NAME","zh");
        Configuration configuration = new Configuration();
        configuration.set("fs.defaultFS","hdfs://192.168.10.100:8020");
        //集群模式   job的对象去提交任务
        Job job = Job.getInstance(configuration);
        //提交我们写的这俩个内部类
        job.setMapperClass(MovieDemo1.MapTask.class);
        job.setReducerClass(MovieDemo1.ReduceTask.class);
        job.setJarByClass(MovieDemo1.class);

        //提交输出参数的类型   注意只要输出参数类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DoubleWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        //如果输出文件存在   就删除
        String outpath="hdfs://192.168.10.100:8020/bigdata/output/mall1";
        FileSystem fileSystem = FileSystem.get(configuration);
        //
        if(fileSystem.exists(new Path(outpath))){
            fileSystem.delete(new Path(outpath),true);
        }

        //告诉输入输出路径
        FileInputFormat.addInputPath(job,new Path("hdfs://192.168.10.100:8020/bigdata/input/2022-06-10.log"));
        FileOutputFormat.setOutputPath(job,new Path(outpath));

        //温馨提示一下
        boolean b = job.waitForCompletion(true);
        System.out.println(b?"老铁,没毛病！！！":"哥们,出BUG了！！！");
    }
}
