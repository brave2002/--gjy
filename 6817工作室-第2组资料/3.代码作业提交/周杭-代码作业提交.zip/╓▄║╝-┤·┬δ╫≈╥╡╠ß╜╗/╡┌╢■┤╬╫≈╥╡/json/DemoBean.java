package MR.json;

import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.lib.db.DBWritable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoBean implements Writable, DBWritable {
    private String name;
    private float money;

    public DemoBean() {
    }

    public DemoBean(String name, float money) {
        this.name = name;
        this.money = money;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getMoney() {
        return money;
    }

    public void setMoney(float money) {
        this.money = money;
    }

    @Override
    public void write(DataOutput out) throws IOException {
        out.writeUTF(name);
        out.writeFloat(money);
    }

    @Override
    public void readFields(DataInput in) throws IOException {
        name=in.readUTF();
        money=in.readFloat();

    }

    @Override
    public void write(PreparedStatement ps) throws SQLException {
        ps.setString(1,name);
        ps.setFloat(2,money);
    }

    @Override
    public void readFields(ResultSet resultSet) throws SQLException {
        name = resultSet.getString(1);
        money = resultSet.getFloat(2);

    }
}
