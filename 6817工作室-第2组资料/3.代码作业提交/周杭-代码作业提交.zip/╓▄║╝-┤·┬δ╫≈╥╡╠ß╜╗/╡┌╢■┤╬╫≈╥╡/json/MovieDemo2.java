package MR.json;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.lib.db.DBConfiguration;
import org.apache.hadoop.mapred.lib.db.DBOutputFormat;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.codehaus.jackson.map.ObjectMapper;

import java.io.IOException;
import java.util.*;

public class MovieDemo2 {


    //map端
    //消费金额排名前10的同学
    public static class MapTask extends Mapper<LongWritable,Text, Text, DoubleWritable>{
        @Override
        protected void map(LongWritable key,Text value,Context context) throws IOException,InterruptedException{
            //json数据不能切分 mr处理
            ObjectMapper mapper =new ObjectMapper();
            //实体类
            MallBean mallBean = mapper.readValue(value.toString(), MallBean.class);
            //
            context.write(new Text(mallBean.getName()),new DoubleWritable(mallBean.getShopPrice()));
        }
    }
    //reduce端
    public static class ReduceTask extends Reducer<Text,DoubleWritable,DemoBean, NullWritable> {
        HashMap<String, Double>hashMap =new HashMap<>();
        @Override           //张三         （5678，2345，123....)
        protected void reduce(Text key,Iterable<DoubleWritable>values,Context context)throws IOException{
            double sum=0;
            for(DoubleWritable value:values){
                sum+=value.get();
            }
            //
            hashMap.put(key.toString(),sum);
        }
        @Override
        protected void cleanup(Context context) throws IOException, InterruptedException{
            Set<Map.Entry<String, Double>> entries =hashMap.entrySet();
            //
            ArrayList<Map.Entry<String,Double>> list = new ArrayList<>(entries);
            //
            list.sort(new Comparator<Map.Entry<String, Double>>() {
                @Override
                public int compare(Map.Entry<String, Double> o1, Map.Entry<String, Double> o2) {
                    return (int)(o2.getValue()-o1.getValue());
                }
            });
            //
            for(int i=0;i<10;i++){
                context.write(new DemoBean(list.get(i).getKey(),Float.parseFloat(list.get(i).getValue().toString())),null);
            }

        }
    }

    //main方法  测试提交任务
    public static void main(String[] args) throws Exception {
        System.setProperty("HADOOP_USER_NAME","zh");
        Configuration configuration = new Configuration();
        configuration.set("fs.defaultFS","hdfs://192.168.10.100:8020");
        //
        DBConfiguration.configureDB(configuration,"com.mysql.jdbc.Driver","jdbc:mysql://192.168.10.100:3306/wode?characterEncoding=utf-8","root","123456");
        //集群模式   job的对象去提交任务
        Job job = Job.getInstance(configuration);
        //提交我们写的这俩个内部类
        job.setMapperClass(MovieDemo2.MapTask.class);
        job.setReducerClass(MovieDemo2.ReduceTask.class);
        job.setJarByClass(MovieDemo2.class);

        //提交输出参数的类型   注意只要输出参数类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DoubleWritable.class);
        job.setOutputKeyClass(DemoBean.class);
        job.setOutputValueClass(NullWritable.class);



        //告诉输入输出路径
        FileInputFormat.addInputPath(job,new Path("hdfs://192.168.10.100:8020/bigdata/input/2022-06-10.log"));
        //告述mysql表
        DBOutputFormat.setOutput(job, "demo", "name","money");

        //温馨提示一下
        boolean b = job.waitForCompletion(true);
        System.out.println(b?"老铁,没毛病！！！":"哥们,出BUG了！！！");
    }
}
