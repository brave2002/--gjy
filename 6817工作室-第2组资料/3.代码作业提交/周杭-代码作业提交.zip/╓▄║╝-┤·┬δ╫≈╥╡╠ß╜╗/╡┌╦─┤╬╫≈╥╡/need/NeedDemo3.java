package need;

import utils.ConnectUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NeedDemo3 {
    static Connection hiveConnection =ConnectUtils.getHiveConnection();
    static Connection mysqlConnection =ConnectUtils.getMysqlConnection();
    //3.统计购买手机的用户占全部用户的比例
    public static void demo3(){
        try {
            PreparedStatement hiveps=hiveConnection.prepareStatement("select round(b.counts/a.sums,2) from\n" +
                    "(select count(distinct name)sums from t_mall)a,\n" +
                    "(select count(distinct name)counts from t_mall where title like '%手机%')b");
            ResultSet resultSet=hiveps.executeQuery();
            //?叫做占位符
            PreparedStatement mysqlps=mysqlConnection.prepareStatement("insert into phone_rate  values (?)");
            while(resultSet.next()){
                mysqlps.setFloat(1,resultSet.getFloat(1));
                //mysqlps.setInt(2,resultSet.getInt(2));
                //提交
                mysqlps.executeUpdate();
            }
            hiveps.close();
            hiveConnection.close();
            mysqlps.close();
            mysqlConnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args){
        demo3();
    }

}
