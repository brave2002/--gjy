package need;

import utils.ConnectUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NeedDemo1 {
    static Connection hiveConnection =ConnectUtils.getHiveConnection();
    static Connection mysqlConnection =ConnectUtils.getMysqlConnection();
    //1.统计每个用户的消费总数，并找出排名前10的用户
    public static void demo1(){
        try {
            PreparedStatement hiveps=hiveConnection.prepareStatement("select name,sum(shopPrice)sums from t_mall group by name order by sums desc limit 10");
            ResultSet resultSet=hiveps.executeQuery();
            //?叫做占位符
            PreparedStatement mysqlps=mysqlConnection.prepareStatement("insert into user_consume values (?,?)");
            while(resultSet.next()){
                mysqlps.setString(1,resultSet.getString("name"));
                mysqlps.setDouble(2,resultSet.getDouble("sums"));
                //提交
                mysqlps.executeUpdate();
            }
            hiveps.close();
            hiveConnection.close();
            mysqlps.close();
            mysqlConnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args){
        demo1();
    }

}
