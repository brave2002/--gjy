package need;

import utils.ConnectUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class NeedDemo4 {
    static Connection hiveConnection =ConnectUtils.getHiveConnection();
    static Connection mysqlConnection =ConnectUtils.getMysqlConnection();
    //4.统计消费排名前5的同学都购买了哪些相同的商品
    public static void demo4(){
        try {
            PreparedStatement hiveps=hiveConnection.prepareStatement("select e.dbtitle from\n" +
                    "(select d.btitle dbtitle,count(*)counts from\n" +
                    "(select b.name,b.title btitle from \n" +
                    "(select name,count(*)sums from t_mall \n" +
                    "group by name order by sums desc limit 5)a\n" +
                    "join t_mall b on a.name=b.name\n" +
                    "group by b.name,b.title)d\n" +
                    "group by d.btitle)e\n" +
                    "where counts=5");
            ResultSet resultSet=hiveps.executeQuery();
            //?叫做占位符
            PreparedStatement mysqlps=mysqlConnection.prepareStatement("insert into product_common values (?)");
            while(resultSet.next()){
                mysqlps.setString(1,resultSet.getString(1));
                //mysqlps.setInt(2,resultSet.getInt(2));
                //提交
                mysqlps.executeUpdate();
            }
            hiveps.close();
            hiveConnection.close();
            mysqlps.close();
            mysqlConnection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args){
        demo4();
    }

}
