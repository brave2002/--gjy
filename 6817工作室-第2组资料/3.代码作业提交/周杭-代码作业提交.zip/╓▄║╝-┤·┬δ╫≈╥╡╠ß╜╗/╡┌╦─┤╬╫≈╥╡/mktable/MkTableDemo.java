package mktable;

import utils.ConnectUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class MkTableDemo {
    static Connection hiveConnection =ConnectUtils.getHiveConnection();
    /**
     * 把三天的json数据表 融合在一起
     */

    public static void createTmpTable(){
        //创建临时表
        try {
            PreparedStatement ps=hiveConnection.prepareStatement("create external table tmp_mall(line string)" +
                    "location '/hivedata/gmall'");
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void createTable(){
        //创建临时表
        try {
            PreparedStatement ps=hiveConnection.prepareStatement("create table t_mall as\n"+
                    "(select json_tuple(line,'name','phoneNumber','productId',\n"+
                    "'shopPrice','times','title')as(name,phoneNumber,productId,\n"+
                    "shopPrice,times,title) from tmp_mall)");
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args){

        createTable();
        //createTmpTable();

    }
}
